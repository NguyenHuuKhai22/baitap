package com.huu.khai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class
KhaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(KhaiApplication.class, args);
	}

}
